


#define __PRINTF_C__


#include "stm32f4xx.h"
#include "stdio.h"
#include "math.h"
#include "printf.h"
#include "string.h"
#include "delay.h"
#include "usart1.h"
#include "spi.h"
#include "max21100.h"
#include "ms5611.h"






void  TO_PC(void)
{

	//MAX21100���ݴ�ӡ				
	printf("ax:");
	printf("%d",MAX21100_ACC_LAST.X);
	printf("\r\n");
	
	printf("ay:");
	printf("%d",MAX21100_ACC_LAST.Y);
	printf("\r\n");
	
	printf("az:");
	printf("%d",MAX21100_ACC_LAST.Z);
	printf("\r\n");
	
	printf("gx:");
	printf("%d",MAX21100_GYRO_LAST.X);
	printf("\r\n");
	
	printf("gy:");
	printf("%d",MAX21100_GYRO_LAST.Y);
	printf("\r\n");
	
	printf("gz:");
	printf("%d",MAX21100_GYRO_LAST.Z);
	printf("\r\n");


	
	
	printf("BaroAlt:");
	printf("%.2f M",MS5611.BaroAlt);
	printf("\r\n");
	
	
	printf("pressure:");
	printf("%d Pa",MS5611.pressure);
	printf("\r\n");
	
	
	printf("temperature:");
	printf("%.2f  C",MS5611.temperature/100.0f);
	printf("\r\n");
	


}


