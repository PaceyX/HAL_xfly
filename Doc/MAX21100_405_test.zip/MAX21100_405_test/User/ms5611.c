
#define __MS5611_C__

#include "stm32f4xx.h"
#include "stdio.h"
#include "math.h"
#include "printf.h"
#include "string.h"
#include "delay.h"
#include "usart1.h"
#include "spi.h"
#include "max21100.h"
#include "ms5611.h"






#define MS5611_FILTER_NUM 10					//�����˲�����


float MS5611_BUF[MS5611_FILTER_NUM];

float MS5611_LAST;



/******************************************************************
									  MS_CS GPIO��ʼ��
******************************************************************/
static void ms5611_cs_config(void)
{
		GPIO_InitTypeDef  GPIO_InitStructure;//GPIO��ʼ���ṹ��
  	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE);//����ʱ��ʹ��
  	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;//��ӦGPIO����
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;//״̬Ϊ���
  	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;//IO�ٶ�Ϊ50MHZ
  	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//����
  	GPIO_Init(GPIOC, &GPIO_InitStructure);//��ʼ��GPIO
	  CS_MS1;

}


/******************************************************************
									  ��ʼ����λ����
******************************************************************/
static void ms5611_reset(void)
{
    CS_MS0;
		SPI1_ReadWriteByte(CMD_RESET);
	  CS_MS1;
}


/******************************************************************
									  ��ȡ����У׼PROM
******************************************************************/
static void ms5611_read_prom(void)
{
		u8 i = 0;
    u8 rxbuf[2] = { 0, 0 };
		for (i = 0; i < PROM_NB; i++)
		{
			CS_MS0;
			SPI1_ReadWriteByte(CMD_PROM_RD + i * 2);
			rxbuf[0] = SPI1_ReadWriteByte(0X00);
			rxbuf[1] = SPI1_ReadWriteByte(0X00);
			ms5611_prom[i] = rxbuf[0] << 8 | rxbuf[1];
			delay_ms(1);
			CS_MS1;
		}
}

/******************************************************************
									  ��ȡ24λADCֵ
******************************************************************/
static uint32_t ms5611_read_adc(void)
{
    uint8_t rxbuf[3];
		CS_MS0;
	  SPI1_ReadWriteByte(CMD_ADC_READ);
	  rxbuf[0] = SPI1_ReadWriteByte(0X00);
	  rxbuf[1] = SPI1_ReadWriteByte(0X00);
	  rxbuf[2] = SPI1_ReadWriteByte(0X00);
	  CS_MS1;
    return (rxbuf[0] << 16) | (rxbuf[1] << 8) | rxbuf[2];
}

/******************************************************************
									  ��ʼ�¶�ת��
******************************************************************/
void ms5611_start_ut(void)
{
    CS_MS0;
	  SPI1_ReadWriteByte(CMD_ADC_CONV + CMD_ADC_D2 + MS5611_OSR);
		CS_MS1;
}



/******************************************************************
									  ��ʼ��ѹת��
******************************************************************/
void ms5611_start_up(void)
{
  CS_MS0;  
	SPI1_ReadWriteByte(CMD_ADC_CONV + CMD_ADC_D1 + MS5611_OSR);
	CS_MS1;

}



/******************************************************************
									  ��ȡ�¶�ֵ
******************************************************************/
void ms5611_get_ut(void)
{
    ms5611_ut = ms5611_read_adc();
}


/******************************************************************
									 ��ȡ��ѹֵ
******************************************************************/
void ms5611_get_up(void)
{
    ms5611_up = ms5611_read_adc();
}


/******************************************************************
									  ������ѹ���¶�
******************************************************************/
static float ms5611_calculate(void)
{	
		int32_t  off2 = 0, sens2 = 0, delt; 

    int32_t dT = (int32_t)ms5611_ut - ((int32_t)ms5611_prom[5] << 8);
    int64_t off = ((uint32_t)ms5611_prom[2] << 16) + (((int64_t)dT * ms5611_prom[4]) >> 7);
    int64_t sens = ((uint32_t)ms5611_prom[1] << 15) + (((int64_t)dT * ms5611_prom[3]) >> 8);
    MS5611.temperature = 2000 + (((int64_t)dT * ms5611_prom[6]) >> 23);

    if (MS5611.temperature < 2000) // temperature lower than 20degC 
		{ 
        delt = MS5611.temperature - 2000;
        delt = 5*delt * delt;
        off2 = delt >> 1;
        sens2 = delt >> 2;
        if (MS5611.temperature < -1500) // temperature lower than -15degC
				{		
            delt = MS5611.temperature + 1500;
            delt = delt * delt;
            off2  += 7 * delt;
            sens2 += (11 * delt) >> 1;
        }
    }
    off  -= off2; 
    sens -= sens2;
    MS5611.pressure = (((ms5611_up * sens ) >> 21) - off) >> 15;		
		return  (float)((1.0f - pow((MS5611.pressure) / 101325.0f, 0.190295f)) * 44330);// ��
}


/******************************************************************
									  MS5611��ʼ��
******************************************************************/
void MS5611_Init(void)
{
	  u8 i;
	  float sum = 0.0f;
		MS5611.BaroAltOffset = 0.0f;
		ms5611_cs_config();
		ms5611_reset();
		delay_ms(500);
		ms5611_read_prom();
		delay_ms(500);
	
	      		
	   //MS5611У��
		for(i=0;i<10;i++)
		{

			ms5611_start_ut();
			delay_ms(10);
			ms5611_get_ut();   //400us
			delay_ms(10);
			ms5611_start_up();
			delay_ms(10);
			ms5611_get_up();
			MS5611_Cal();   //400us
			sum +=MS5611_LAST;
			delay_ms(100);

		}
		MS5611.BaroAltOffset = sum / 10.0f;
}



/******************************************************************
									  �����˲�
******************************************************************/
static void MS5611_filter(void)
{
	static uint8_t filter_cnt=0;
	float temp=0.0f;
	uint8_t i;	
	
	MS5611_BUF[filter_cnt] = MS5611_LAST;//���»�����������


	for(i=0;i<MS5611_FILTER_NUM;i++)
	{
		temp += MS5611_BUF[i];

	}

	MS5611.BaroAlt = temp / MS5611_FILTER_NUM;


	filter_cnt++;
	if(filter_cnt==MS5611_FILTER_NUM)	filter_cnt=0;
	
}



/******************************************************************
									  �õ����θ߶�
******************************************************************/
void MS5611_Cal(void)
{

	MS5611_LAST = ms5611_calculate() - MS5611.BaroAltOffset;
	MS5611_filter();

}





