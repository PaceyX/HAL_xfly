#include "stm32f4xx.h"
#include "hmc5983.h"

#define HMC5983	I2C2

int16_t	magg[4];

//SCL,SDA
void GPIO_IIC_Config(void)
{
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_I2C2, ENABLE);
	GPIO_InitTypeDef GPIO_InitStructure;
	
	GPIO_PinAFConfig(GPIOB, GPIO_PinSource10, GPIO_AF_I2C2);
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource11, GPIO_AF_I2C2);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10 | GPIO_Pin_11;
    GPIO_InitStructure.GPIO_Speed = GPIO_Fast_Speed;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

	I2C_Config();
	
}

void I2C_Config(void)
{
		I2C_InitTypeDef  I2C_InitStructure; 
	
		I2C_InitStructure.I2C_ClockSpeed = 400000;
		I2C_InitStructure.I2C_Mode = I2C_Mode_I2C;
		I2C_InitStructure.I2C_DutyCycle = I2C_DutyCycle_2;
		I2C_InitStructure.I2C_OwnAddress1 = 0x02;
		I2C_InitStructure.I2C_Ack = I2C_Ack_Enable;
		I2C_InitStructure.I2C_AcknowledgedAddress = I2C_AcknowledgedAddress_7bit;
		
		I2C_Init(I2C2, &I2C_InitStructure);
		I2C_Cmd(I2C2, ENABLE);
		
		I2C_AcknowledgeConfig(I2C2, ENABLE);//ASK

}




void HMC5983_Init(void)
{

		// 0x98 = 0b10011000
		// Enable Temperature Sensor
		// ODR = 75Hz
		HMC5983_WriteReg(HMC5983_CFG_A, 0x98);
		delay_ms(100);
			

		// 0x00 = 0b00000000
		// Continuous-Measurement Mode
		HMC5983_WriteReg(HMC5983_MODE, 0x00);	
		delay_ms(100);
	
}

void HMC5983_ReadMag(int16_t *Mag)
{
	uint8_t buf[6];
	static u8 temp = 2; 
	if(temp == 2)		//take mag data per 2ms
	{
		temp = 0;
		HMC5983_ReadMultReg((HMC5983_X_M | (1<<7)), buf, 6);
	}
	else
	{		
		Mag[0] = (int16_t)(buf[0] << 8 | buf[1]);//Mx
		Mag[1] = (int16_t)(buf[2] << 8 | buf[3]);//My
		Mag[2] = (int16_t)(buf[4] << 8 | buf[5]);//Mz
	}
	temp++;
}

void HMC5983_Get_Offset(int16_t *MagBias)
{
		uint8_t i, j;
		uint8_t buf[6];		
		int16_t  Mag_max[3], Mag_min[3];
			
		for(i=0;i<128;i++)
		{
			int16_t Magtemp[3];
			HMC5983_ReadMultReg((HMC5983_X_M | (1<<7)), buf, 6);
			Magtemp[0] = (float)(buf[0] << 8 | buf[1]);//Mx
			Magtemp[1] = (float)(buf[2] << 8 | buf[3]);//My
			Magtemp[2] = (float)(buf[4] << 8 | buf[5]);//Mz
			for (j = 0; j < 3; j++) 
			{
					if(Magtemp[j] > Mag_max[j]) 
						Mag_max[j] = Magtemp[j];
					
					if(Magtemp[j] < Mag_min[j]) 
						Mag_min[j] = Magtemp[j];
			}
			delay_ms(15); // at 75 Hz ODR, new mag data is available every 13.33 ms
			
		}
				
		MagBias[0] = (Mag_max[0] + Mag_min[0])/2;
		MagBias[1] = (Mag_max[1] + Mag_min[1])/2;
		MagBias[2] = (Mag_max[2] + Mag_min[2])/2;
		
		MagBias[0] *= -1;
		MagBias[1] *= -1;
		MagBias[2] *= -1;
				
}


void HMC5983_WriteReg(uint8_t reg, uint8_t value)
{
		while(I2C_GetFlagStatus(HMC5983, I2C_FLAG_BUSY));

		I2C_GenerateSTART(HMC5983, ENABLE);
		while(!I2C_CheckEvent(HMC5983, I2C_EVENT_MASTER_MODE_SELECT));
			
		I2C_Send7bitAddress(HMC5983, MHC5983_ADDRESS_WRITE, I2C_Direction_Transmitter);
		while(!I2C_CheckEvent(HMC5983, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED));
		I2C_AcknowledgeConfig(HMC5983, ENABLE);//ASK
				
		I2C_SendData(HMC5983, reg);
		while(!I2C_CheckEvent(HMC5983, I2C_EVENT_MASTER_BYTE_TRANSMITTED));
		I2C_AcknowledgeConfig(HMC5983, ENABLE);//ASK

		I2C_SendData(HMC5983, value);
		while(!I2C_CheckEvent(HMC5983, I2C_EVENT_MASTER_BYTE_TRANSMITTED));
		I2C_AcknowledgeConfig(HMC5983, ENABLE);//ASK

		I2C_GenerateSTOP(HMC5983, ENABLE);
}

void HMC5983_ReadMultReg(uint8_t reg, uint8_t *buf, uint16_t num)
{
		uint8_t i;
		
		while(I2C_GetFlagStatus(HMC5983, I2C_FLAG_BUSY));
	  
		I2C_GenerateSTART(HMC5983, ENABLE);
		while(!I2C_CheckEvent(HMC5983, I2C_EVENT_MASTER_MODE_SELECT));
		
		I2C_Send7bitAddress(HMC5983, MHC5983_ADDRESS_WRITE, I2C_Direction_Transmitter);
		while (!I2C_CheckEvent(HMC5983, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED));

		I2C_SendData(HMC5983, reg);
		while (!I2C_CheckEvent(HMC5983, I2C_EVENT_MASTER_BYTE_TRANSMITTED));
		
		I2C_GenerateSTART(HMC5983, ENABLE);
		while(!I2C_CheckEvent(HMC5983, I2C_EVENT_MASTER_MODE_SELECT));
		 
		I2C_Send7bitAddress(HMC5983, MHC5983_ADDRESS_READ, I2C_Direction_Receiver);
		while(!I2C_CheckEvent(HMC5983, I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED)); 
		
		for (i = 0; i < num; i++)
		{
				if (i == (num - 1)) 
				{
						/* Last byte */
						I2C_AcknowledgeConfig(HMC5983, DISABLE);//NASK
						I2C_GenerateSTOP(HMC5983, ENABLE);
						while(!I2C_CheckEvent(HMC5983, I2C_EVENT_MASTER_BYTE_RECEIVED));  
						*buf = I2C_ReceiveData(HMC5983);
					
				}
				else
				{
						/* Frist byte start */
						I2C_AcknowledgeConfig(HMC5983, ENABLE);//ASK
						while(!I2C_CheckEvent(HMC5983, I2C_EVENT_MASTER_BYTE_RECEIVED));
						*buf = I2C_ReceiveData(HMC5983);
										
				}
				buf++;
		}
				
}
