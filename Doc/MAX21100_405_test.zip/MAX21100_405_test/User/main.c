#include "stm32f4xx.h"
#include "stdio.h"
#include "math.h"
#include "printf.h"
#include "string.h"
#include "delay.h"
#include "usart1.h"
#include "spi.h"
#include "max21100.h"
#include "ms5611.h"




void SYS_Init(void)
{
	
	
	delay_init(168);		     
		
  delay_ms(500);	
	
	USART1_Configuration();   
	
	SPI1_Master_Init();			//SPI��ʼ��
	
	delay_ms(200);	        


	MAX21100_Init();			//MAX21100��ʼ��
	delay_ms(200);
	GET_MAX21100_ID();			
	printf("MAX21100...IS.....OK\r\n");
	
//	CS_MS0;
//	MS5611_Init();				//MS5611��ʼ��
//	CS_MS1;
	delay_ms(200);
	printf("MS5611...IS.....OK\r\n");	

}



int main(void)
{

	SYS_Init();
	
	while(1)
	{
		MAX21100_getMotion6();
		
//		ms5611_start_ut();
//		delay_ms(10);
//		ms5611_get_ut();   //400us
//		delay_ms(10);
//		ms5611_start_up();
//		delay_ms(10);
//		ms5611_get_up();
//		MS5611_Cal();   //400us
		
		TO_PC();
		delay_ms(100);
	}
}


