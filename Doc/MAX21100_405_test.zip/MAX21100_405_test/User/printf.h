



#ifndef __PRINTF_H__
#define	__PRINTF_H__


#include "stm32f4xx.h"


#ifndef __PRINTF_C__
#define EXT_PRINTF extern

#else 
#define EXT_PRINTF   	        


#endif




EXT_PRINTF void  TO_PC(void);




#endif



